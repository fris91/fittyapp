create function rpad(text, integer) returns text
    immutable
    strict
    parallel safe
    cost 1
    language sql
RETURN rpad($1, $2, ' '::text);

comment on function rpad(text, integer) is 'right-pad string to length';

alter function rpad(text, integer) owner to fris91;


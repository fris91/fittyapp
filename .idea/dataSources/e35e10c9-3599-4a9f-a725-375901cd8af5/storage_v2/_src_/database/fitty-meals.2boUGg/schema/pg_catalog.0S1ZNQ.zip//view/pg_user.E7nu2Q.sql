create view pg_user (usename, usesysid, usecreatedb, usesuper, userepl, usebypassrls, passwd, valuntil, useconfig) as
SELECT usename,
       usesysid,
       usecreatedb,
       usesuper,
       userepl,
       usebypassrls,
       '********'::text AS passwd,
       valuntil,
       useconfig
FROM pg_shadow;

alter table pg_user
    owner to fris91;

grant select on pg_user to public;


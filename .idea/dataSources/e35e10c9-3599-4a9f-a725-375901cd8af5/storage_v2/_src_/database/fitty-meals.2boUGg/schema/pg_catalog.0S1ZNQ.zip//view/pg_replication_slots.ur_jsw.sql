create view pg_replication_slots
            (slot_name, plugin, slot_type, datoid, database, temporary, active, active_pid, xmin, catalog_xmin,
             restart_lsn, confirmed_flush_lsn, wal_status, safe_wal_size, two_phase, conflicting)
as
SELECT l.slot_name,
       l.plugin,
       l.slot_type,
       l.datoid,
       d.datname AS database,
       l.temporary,
       l.active,
       l.active_pid,
       l.xmin,
       l.catalog_xmin,
       l.restart_lsn,
       l.confirmed_flush_lsn,
       l.wal_status,
       l.safe_wal_size,
       l.two_phase,
       l.conflicting
FROM pg_get_replication_slots() l(slot_name, plugin, slot_type, datoid, temporary, active, active_pid, xmin,
                                  catalog_xmin, restart_lsn, confirmed_flush_lsn, wal_status, safe_wal_size, two_phase,
                                  conflicting)
         LEFT JOIN pg_database d ON l.datoid = d.oid;

alter table pg_replication_slots
    owner to fris91;

grant select on pg_replication_slots to public;


create function "overlaps"(timestamp without time zone, interval, timestamp without time zone, interval) returns boolean
    immutable
    parallel safe
    cost 1
    language sql
RETURN (($1, ($1 + $2)) OVERLAPS ($3, ($3 + $4)));

comment on function "overlaps"(timestamp, interval, timestamp, interval) is 'intervals overlap?';

alter function "overlaps"(timestamp, interval, timestamp, interval) owner to fris91;

